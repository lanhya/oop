export class Student {
  name: string;

  constructor(name: string) {
    this.name = name;
  }
}
