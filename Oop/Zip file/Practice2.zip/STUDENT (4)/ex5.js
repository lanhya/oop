// Instructions:
// • Add type annotations (as explicit as possible)
// • Fix errors (if applicable)
var sequence = [1, 2, 3, 4, 5, 6];
var animals = ["pangolin", "monkey", "cat", "dog"];
var stringsAndNumbers = [1, "one", 2, "two", 3, "three"];
var allMyArrays = [sequence, animals, stringsAndNumbers];
console.log("Exercise 1.5", allMyArrays);
