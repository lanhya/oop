export class Door {
  color: string;
  
  constructor(color: string) {
    this.color = color;
  }
}
