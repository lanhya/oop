"use strict";
exports.__esModule = true;
exports.Room = void 0;
var Room = /** @class */ (function () {
    function Room(name) {
        this.door = [];
        this.name = name;
    }
    return Room;
}());
exports.Room = Room;
