"use strict";
exports.__esModule = true;
exports.Customer = void 0;
var Customer = /** @class */ (function () {
    function Customer(firstName, lastName, haveAddress) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.haveAddress = haveAddress;
    }
    return Customer;
}());
exports.Customer = Customer;
