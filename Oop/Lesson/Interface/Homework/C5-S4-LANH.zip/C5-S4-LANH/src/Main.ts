import { Vehicle } from "./Vehicle";
import { VehicleConvey } from "./VehicleConvey";

let cvonvey = new VehicleConvey();
console.log(cvonvey);
let vi = new Vehicle("12",12);
