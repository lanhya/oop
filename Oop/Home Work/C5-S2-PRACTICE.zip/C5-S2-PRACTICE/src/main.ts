import { Circle } from "./circle";
import { Ractangle } from "./ractangle";

// let ci = new Circle(2,2,2);
// console.log(ci.getArea());
let are = new Ractangle(-1,-1, 5, 3);
console.log(are.getHeight())